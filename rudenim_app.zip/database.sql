CREATE DATABASE rudenim;
USE rudenim;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password TEXT,
 role VARCHAR(20)
);

INSERT INTO users VALUES(NULL,'admin','$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG','admin');

CREATE TABLE log_deteni(
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(100),
 status VARCHAR(10)
);

CREATE TABLE barang(
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama_deteni VARCHAR(100),
 barang VARCHAR(100),
 jumlah INT,
 foto TEXT
);
