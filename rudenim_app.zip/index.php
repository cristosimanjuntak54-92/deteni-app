<?php
$conn = mysqli_connect("localhost","root","","rudenim");
session_start();

function aman($data){
 global $conn;
 return mysqli_real_escape_string($conn, htmlspecialchars($data));
}

if(isset($_POST['login'])){
 $u = aman($_POST['username']);
 $p = $_POST['password'];
 $q = mysqli_query($conn,"SELECT * FROM users WHERE username='$u'");
 $d = mysqli_fetch_array($q);
 if($d && password_verify($p,$d['password'])){
  $_SESSION['login']=true;
  $_SESSION['role']=$d['role'];
  $_SESSION['nama']=$d['username'];
 } else echo "Login gagal";
}

if(isset($_GET['logout'])){
 session_destroy(); header("Location:index.php");
}
?>
<style>
body{font-family:Segoe UI;background:#eef2f7;margin:0}
.nav{background:#0b3d91;color:white;padding:15px}
.container{width:95%;margin:auto}
.card{background:white;padding:20px;margin-top:20px;border-radius:10px}
button{background:#0b3d91;color:white;padding:10px;border:none;border-radius:5px}
input,select{padding:8px;margin:5px;width:100%}
table{width:100%;margin-top:10px;border-collapse:collapse}
th,td{padding:10px;border-bottom:1px solid #ccc}
th{background:#0b3d91;color:white}
</style>

<?php if(!isset($_SESSION['login'])){ ?>
<div class='container'><div class='card'>
<h2>Login Sistem Deteni</h2>
<form method='POST'>
<input name='username' placeholder='Username' required>
<input type='password' name='password' placeholder='Password' required>
<button name='login'>Login</button>
</form>
</div></div>
<?php } else { ?>

<div class='nav'>
SISTEM DETENI | <?= $_SESSION['nama'] ?> (<?= $_SESSION['role'] ?>)
 | <a href='?logout=1' style='color:white'>Logout</a>
</div>

<div class='container'>

<div class='card'>
<h3>Input Keluar/Masuk</h3>
<form method='POST'>
<input name='nama' placeholder='Nama Deteni' required>
<select name='status'><option>Masuk</option><option>Keluar</option></select>
<button name='simpan'>Simpan</button>
</form>
</div>

<div class='card'>
<h3>Barang Titipan</h3>
<form method='POST' enctype='multipart/form-data'>
<input name='nama_deteni' placeholder='Nama Deteni' required>
<input name='barang' placeholder='Barang' required>
<input type='number' name='jumlah' placeholder='Jumlah' required>
<input type='file' name='foto' required>
<button name='simpan_barang'>Simpan</button>
</form>
</div>

<div class='card'>
<h3>Data Barang</h3>
<table>
<tr><th>Nama</th><th>Barang</th><th>Foto</th></tr>
<?php
$q=mysqli_query($conn,"SELECT * FROM barang");
while($b=mysqli_fetch_array($q)){
 echo "<tr>
 <td>{$b['nama_deteni']}</td>
 <td>{$b['barang']}</td>
 <td><img src='upload/{$b['foto']}' width='60'></td>
 </tr>";
}
?>
</table>
</div>

</div>
<?php } ?>

<?php
if(isset($_POST['simpan'])){
 mysqli_query($conn,"INSERT INTO log_deteni(nama,status) VALUES('$_POST[nama]','$_POST[status]')");
 header("Location:index.php");
}

if(isset($_POST['simpan_barang'])){
 $foto = time()."_".$_FILES['foto']['name'];
 move_uploaded_file($_FILES['foto']['tmp_name'],"upload/".$foto);
 mysqli_query($conn,"INSERT INTO barang(nama_deteni,barang,jumlah,foto)
 VALUES('$_POST[nama_deteni]','$_POST[barang]','$_POST[jumlah]','$foto')");
 header("Location:index.php");
}
?>
